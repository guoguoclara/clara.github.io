import {join} from "path";

export const COOKIE_FILE = join(__dirname, '../storage/cookie.json')